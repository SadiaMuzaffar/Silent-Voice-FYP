package com.example.silentvoice

import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.preference.ListPreference
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import androidx.lifecycle.lifecycleScope
import com.example.silentvoice.data.AppDatabase
import kotlinx.coroutines.launch
import java.util.Locale

class SettingsFragment : PreferenceFragmentCompat() {

    private lateinit var tts: TextToSpeech

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.settings_preferences, rootKey)

        tts = TextToSpeech(requireContext()) {}

        // ===== TTS Language & Voice =====
        val languagePref: ListPreference? = findPreference("tts_language")
        val voicePref: ListPreference? = findPreference("tts_voice")

        val checkVoiceAvailability: () -> Unit = {
            val lang = languagePref?.value ?: "English"
            val voice = voicePref?.value ?: "Male"
            val locale = when (lang.lowercase()) {
                "urdu" -> Locale("ur")
                else -> Locale.US
            }

            val availableVoice = tts.voices.firstOrNull {
                it.locale.language == locale.language &&
                        it.name.contains(voice.lowercase())
            }


        }

        languagePref?.setOnPreferenceChangeListener { _, _ ->
            checkVoiceAvailability()
            true
        }

        voicePref?.setOnPreferenceChangeListener { _, _ ->
            checkVoiceAvailability()
            true
        }

        // ===== Clear History =====
        val clearHistoryPref: Preference? = findPreference("clear_history")
        val gestureDao = AppDatabase.getDatabase(requireContext()).gestureDao()

        clearHistoryPref?.setOnPreferenceClickListener {
            lifecycleScope.launch {
                gestureDao.clearAll() // delete all gestures
                Toast.makeText(requireContext(), "History cleared!", Toast.LENGTH_SHORT).show()
            }
            true
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        tts.shutdown()
    }
}
