package com.example.silentvoice.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.silentvoice.data.GestureEntity
import com.example.silentvoice.databinding.ItemGestureBinding
import java.text.SimpleDateFormat
import java.util.*

class GestureAdapter(private var gestureList: List<GestureEntity>) :
    RecyclerView.Adapter<GestureAdapter.GestureViewHolder>() {

    inner class GestureViewHolder(val binding: ItemGestureBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GestureViewHolder {
        val binding = ItemGestureBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return GestureViewHolder(binding)
    }

    override fun onBindViewHolder(holder: GestureViewHolder, position: Int) {
        val gesture = gestureList[position]
        val time = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(gesture.timestamp))
        holder.binding.tvItemGesture.text = gesture.gesture
        holder.binding.tvItemTime.text = time
    }

    override fun getItemCount(): Int = gestureList.size

    fun updateData(list: List<GestureEntity>) {
        gestureList = list
        notifyDataSetChanged()
    }
}
