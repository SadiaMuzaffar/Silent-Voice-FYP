package com.example.silentvoice.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface GestureDao {

    @Insert
    suspend fun insertGesture(gesture: GestureEntity)

    @Query("SELECT * FROM gesture_history ORDER BY timestamp DESC")
    fun getAllGestures(): Flow<List<GestureEntity>> // Flow so RecyclerView updates live

    // ===== Added function to clear all gestures =====
    @Query("DELETE FROM gesture_history")
    suspend fun clearAll()
}
