package com.example.silentvoice

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.silentvoice.data.AppDatabase
import com.example.silentvoice.ui.adapter.GestureAdapter
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class HistoryActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: GestureAdapter
    private lateinit var btnBack: MaterialButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        // ------------------- Toolbar Setup -------------------
        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "History"

        // ------------------- RecyclerView Setup -------------------
        recyclerView = findViewById(R.id.rvGestures)
        recyclerView.layoutManager = LinearLayoutManager(this)

        adapter = GestureAdapter(emptyList())
        recyclerView.adapter = adapter

        // ------------------- Optional Back Button -------------------
        btnBack = findViewById(R.id.btnBack)
        btnBack.setOnClickListener { finish() }

        // ------------------- Fetch gestures from database -------------------
        fetchGestures()
    }

    // Toolbar back button functionality
    override fun onSupportNavigateUp(): Boolean {
        finish()  // closes HistoryActivity and goes back
        return true
    }

    private fun fetchGestures() {
        val gestureDao = AppDatabase.getDatabase(this).gestureDao()
        lifecycleScope.launch {
            gestureDao.getAllGestures().collectLatest { gestures ->
                adapter.updateData(gestures)
            }
        }
    }
}
