package com.example.silentvoice

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.*
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.text.Spannable
import android.text.SpannableString
import android.text.style.RelativeSizeSpan
import android.util.TypedValue
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.preference.PreferenceManager
import com.example.silentvoice.data.*
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.launch
import java.io.IOException
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.*
import java.util.Collections
import org.tensorflow.lite.Interpreter

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var tts: TextToSpeech
    private lateinit var tvGesture: TextView
    private lateinit var gestureDao: GestureDao

    // Bluetooth
    private lateinit var bluetoothAdapter: BluetoothAdapter
    private var bluetoothSocket: BluetoothSocket? = null
    private var inputStream: InputStream? = null

    // ML
    private lateinit var tflite: Interpreter
    private val fullBuffer = StringBuilder()
    private val frameBuffer = Collections.synchronizedList(mutableListOf<FloatArray>())

    // Gesture validation
    private var lastSpokenGesture = ""
    private var consecutiveCount  = 0
    private var framesSinceLastRun = 0
    private var isHandActive       = false
    private val CONFIDENCE_THRESHOLD = 0.75f  // 75% confident minimum
    private val CONSECUTIVE_NEEDED   = 3       // same gesture 3 times in a row
    private val RUN_EVERY_N_FRAMES   = 10      // only run model every 10 new frames

    private val labels = listOf(
        "A","B","C","D","E","F","G","H","I","J",
        "K","L","M","N","O","P","Q","R","S","T",
        "U","V","W","X","Y","Z",
        "yes","you","no","me"
    )

    private val dummyGestures = listOf("A", "B", "C")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val toolbar: MaterialToolbar = findViewById(R.id.topAppBar)
        setSupportActionBar(toolbar)

        val title = SpannableString("SilentVoice")
        title.setSpan(RelativeSizeSpan(1.3f), 0, title.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        supportActionBar?.title = title

        val rootView: View = findViewById(R.id.coordinatorLayout)
        ViewCompat.setOnApplyWindowInsetsListener(rootView) { v, insets ->
            val sys = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(sys.left, sys.top, sys.right, sys.bottom)
            insets
        }

        tvGesture = findViewById(R.id.tvGesture)
        val btnTTS: MaterialButton    = findViewById(R.id.btnTTS)
        val btnHistory: MaterialButton = findViewById(R.id.btnHistory)
        val btnConnect: MaterialButton = findViewById(R.id.btnConnect)

        tts = TextToSpeech(this, this)
        gestureDao = AppDatabase.getDatabase(this).gestureDao()

        loadModel()

        val bluetoothManager = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = bluetoothManager.adapter

        // ✅ Safe Bluetooth enable request — guarded by permission check
        if (hasBtConnectPermission() && !bluetoothAdapter.isEnabled) {
            startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
        }

        requestBtPermissions()
        showDummyGesture()

        btnConnect.setOnClickListener { connectBluetooth() }

        btnTTS.setOnClickListener {
            val gestureText = tvGesture.text.toString()
            applyTTSSettings()
            speakGesture(gestureText)
            saveGestureToHistory(gestureText)
        }

        btnHistory.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
    }

    // ─────────────────────────────────────────────
    // ✅ PERMISSION HELPERS
    // ─────────────────────────────────────────────

    /** Returns true if BLUETOOTH_CONNECT is granted (Android 12+) or not needed (< 12). */
    private fun hasBtConnectPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(
                this, Manifest.permission.BLUETOOTH_CONNECT
            ) == PackageManager.PERMISSION_GRANTED
        } else true
    }

    /** Returns true if BLUETOOTH_SCAN is granted (Android 12+) or not needed (< 12). */
    private fun hasBtScanPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(
                this, Manifest.permission.BLUETOOTH_SCAN
            ) == PackageManager.PERMISSION_GRANTED
        } else true
    }

    private fun requestBtPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val missing = mutableListOf<String>()
            if (!hasBtConnectPermission()) missing.add(Manifest.permission.BLUETOOTH_CONNECT)
            if (!hasBtScanPermission())   missing.add(Manifest.permission.BLUETOOTH_SCAN)
            if (missing.isNotEmpty()) {
                ActivityCompat.requestPermissions(this, missing.toTypedArray(), REQUEST_BT)
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        results: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == REQUEST_BT) {
            if (results.isNotEmpty() && results.all { it == PackageManager.PERMISSION_GRANTED }) {
                Toast.makeText(this, "Permissions granted ✅", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Bluetooth permissions denied ❌\nApp cannot connect.", Toast.LENGTH_LONG).show()
            }
        }
    }

    // ─────────────────────────────────────────────
    // 🔥 LOAD TFLITE MODEL
    // ─────────────────────────────────────────────

    private fun loadModel() {
        try {
            Log.e("TFLITE", "Assets list: ${assets.list("")?.toList()}")
            val fileDescriptor = assets.openFd("asl_model_75.tflite")
            val stream = fileDescriptor.createInputStream()
            val bytes  = stream.readBytes()
            Log.d("TFLITE", "Model file size: ${bytes.size} bytes")

            val buffer = ByteBuffer.allocateDirect(bytes.size).apply {
                order(ByteOrder.nativeOrder())
                put(bytes)
            }
            tflite = Interpreter(buffer)

            // ✅ Log model shape immediately after loading
            val inShape  = tflite.getInputTensor(0).shape()
            val outShape = tflite.getOutputTensor(0).shape()
            Log.d("TFLITE", "✅ Model loaded OK")
            Log.d("TFLITE", "   Input shape:  ${inShape.toList()}")
            Log.d("TFLITE", "   Output shape: ${outShape.toList()}")

            runOnUiThread {
                Toast.makeText(this, "Model loaded ✅", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Log.e("TFLITE", "❌ Load failed: ${e.message}", e)
            runOnUiThread {
                Toast.makeText(this, "Model load failed ❌: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    // ─────────────────────────────────────────────
    // 🔵 BLUETOOTH — CONNECT
    // ─────────────────────────────────────────────

    @SuppressLint("MissingPermission") // Permission is checked manually below before every BT call
    private fun connectBluetooth() {

        // ✅ Guard: check CONNECT permission before doing anything
        if (!hasBtConnectPermission()) {
            Toast.makeText(this, "Bluetooth permission required ❌\nPlease grant it in Settings.", Toast.LENGTH_LONG).show()
            requestBtPermissions()
            return
        }

        // ✅ Close any existing connection first
        closeSocket()

        val deviceAddress = "00:21:13:00:A2:72"

        Thread {
            try {
                // ✅ getRemoteDevice — needs BLUETOOTH_CONNECT on Android 12+
                val device: BluetoothDevice = try {
                    bluetoothAdapter.getRemoteDevice(deviceAddress)
                } catch (e: SecurityException) {
                    Log.e("BT", "getRemoteDevice denied: ${e.message}")
                    runOnUiThread {
                        Toast.makeText(this, "Permission denied for getRemoteDevice ❌", Toast.LENGTH_SHORT).show()
                    }
                    return@Thread
                }

                val uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

                // ✅ cancelDiscovery — needs BLUETOOTH_SCAN on Android 12+
                if (hasBtScanPermission()) {
                    try {
                        bluetoothAdapter.cancelDiscovery()
                    } catch (e: SecurityException) {
                        Log.w("BT", "cancelDiscovery denied (non-fatal): ${e.message}")
                    }
                }

                // ✅ createRfcommSocketToServiceRecord — needs BLUETOOTH_CONNECT
                val socket: BluetoothSocket = try {
                    device.createRfcommSocketToServiceRecord(uuid)
                } catch (e: SecurityException) {
                    Log.e("BT", "createRfcomm denied: ${e.message}")
                    runOnUiThread {
                        Toast.makeText(this, "Permission denied for socket creation ❌", Toast.LENGTH_SHORT).show()
                    }
                    return@Thread
                }

                // ✅ socket.connect() — needs BLUETOOTH_CONNECT
                try {
                    socket.connect()
                    bluetoothSocket = socket
                } catch (e: SecurityException) {
                    Log.e("BT", "socket.connect() denied: ${e.message}")
                    try { socket.close() } catch (_: IOException) {}
                    runOnUiThread {
                        Toast.makeText(this, "Permission denied on connect ❌", Toast.LENGTH_SHORT).show()
                    }
                    return@Thread
                } catch (e: IOException) {
                    // ✅ Secure failed → try insecure fallback
                    Log.w("BT", "Secure connect failed, trying fallback: ${e.message}")
                    try { socket.close() } catch (_: IOException) {}

                    try {
                        val method = device.javaClass.getMethod(
                            "createInsecureRfcommSocket", Int::class.java
                        )
                        val fallbackSocket = method.invoke(device, 1) as BluetoothSocket
                        fallbackSocket.connect()
                        bluetoothSocket = fallbackSocket
                    } catch (se: SecurityException) {
                        Log.e("BT", "Fallback socket permission denied: ${se.message}")
                        runOnUiThread {
                            Toast.makeText(this, "Permission denied on fallback ❌", Toast.LENGTH_SHORT).show()
                        }
                        return@Thread
                    } catch (fe: IOException) {
                        Log.e("BT", "Fallback connect failed: ${fe.message}")
                        runOnUiThread {
                            Toast.makeText(this, "Connection failed ❌ Check device is on & paired.", Toast.LENGTH_LONG).show()
                        }
                        return@Thread
                    }
                }

                // ✅ Get input stream — needs BLUETOOTH_CONNECT
                inputStream = try {
                    bluetoothSocket?.inputStream
                } catch (e: SecurityException) {
                    Log.e("BT", "inputStream denied: ${e.message}")
                    runOnUiThread {
                        Toast.makeText(this, "Permission denied reading stream ❌", Toast.LENGTH_SHORT).show()
                    }
                    closeSocket()
                    return@Thread
                }

                runOnUiThread {
                    Toast.makeText(this, "Connected ✅", Toast.LENGTH_SHORT).show()
                    // ✅ Clear dummy data — show waiting message until real data arrives
                    tvGesture.text = "Waiting for gesture..."
                }

                receiveData()

            } catch (e: Exception) {
                Log.e("BT", "Unexpected error: ${e.message}")
                runOnUiThread {
                    Toast.makeText(this, "Unexpected error ❌: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    // ─────────────────────────────────────────────
    // 🔵 BLUETOOTH — RECEIVE DATA
    // ─────────────────────────────────────────────

    private fun receiveData() {
        val buffer = ByteArray(1024)

        while (true) {
            try {
                val bytes = inputStream?.read(buffer) ?: break

                // ✅ -1 means remote device closed the connection
                if (bytes == -1) {
                    Log.w("BT", "read() returned -1 — device disconnected")
                    runOnUiThread {
                        Toast.makeText(this, "Device disconnected ❌", Toast.LENGTH_SHORT).show()
                    }
                    break
                }

                val chunk = String(buffer, 0, bytes)
                // ✅ Process on BT thread — NOT UI thread
                // UI updates are done inside each function via runOnUiThread
                processIncomingData(chunk)

            } catch (e: IOException) {
                Log.e("BT", "Read failed: ${e.message}")
                runOnUiThread {
                    Toast.makeText(this, "Disconnected ❌ Tap Connect to retry", Toast.LENGTH_SHORT).show()
                }
                break
            }
        }

        closeSocket()
    }

    /** Safely closes inputStream and bluetoothSocket. */
    private fun closeSocket() {
        try { inputStream?.close() }    catch (e: IOException) { Log.w("BT", "stream close: ${e.message}") }
        try { bluetoothSocket?.close() } catch (e: IOException) { Log.w("BT", "socket close: ${e.message}") }
        inputStream   = null
        bluetoothSocket = null
    }

    // ─────────────────────────────────────────────
    // 🔥 DATA PROCESSING
    // ─────────────────────────────────────────────

    private fun processIncomingData(dataChunk: String) {
        fullBuffer.append(dataChunk)

        while (true) {
            val start = fullBuffer.indexOf("<")

            // Discard garbage before the opening bracket
            if (start == -1) { fullBuffer.clear(); break }
            if (start > 0) fullBuffer.delete(0, start)

            val end = fullBuffer.indexOf(">")

            // No closing bracket yet — partial packet, wait for more data
            if (end == -1) break

            // Extract content between < and >
            val packet = fullBuffer.substring(1, end)
            fullBuffer.delete(0, end + 1)

            Log.d("BT_PACKET", "Received: $packet")
            parsePacket(packet)
        }
    }

    private fun parsePacket(packet: String) {
        val values = packet.trim().split(",")
        Log.d("BT_PARSE", "Count=${values.size} values=$values")

        if (values.size == 11) {
            try {
                val frame = FloatArray(11) { i -> values[i].trim().toFloat() }
                addToBuffer(frame)
            } catch (e: NumberFormatException) {
                Log.w("BT_PARSE", "Bad number in: $packet → ${e.message}")
            }
        } else {
            Log.w("BT_PARSE", "Expected 11 values got ${values.size}: $packet")
        }
    }

    private fun addToBuffer(frame: FloatArray) {
        frameBuffer.add(frame)
        if (frameBuffer.size > 100) frameBuffer.removeAt(0)

        val currentSize = frameBuffer.size

        // ✅ Check if hand is actively moving using variance of flex sensors
        // frame indices 0-4 are the 5 flex sensors from your glove
        // WITH THIS:
        isHandActive = isGestureActive(frame)

// Only add frame to buffer if hand is ACTIVE
// This stops transition frames from polluting the buffer!
        if (!isHandActive) {
            runOnUiThread { tvGesture.text = "Rest — hold your gesture steady..." }
            frameBuffer.clear()  // clear so next gesture starts fresh
            consecutiveCount = 0
            lastSpokenGesture = ""
            return  // ← don't add this frame at all
        }

// Hand is active — only NOW add frame to buffer
// (Move frameBuffer.add(frame) to HERE, AFTER the isHandActive check)

        if (currentSize < 100) {
            runOnUiThread {
                tvGesture.text = "Collecting... $currentSize/100"
            }
            return
        }

        // ✅ Don't run model if hand is just resting — avoids garbage prediction
        if (!isHandActive) {
            runOnUiThread { tvGesture.text = "Rest — waiting for gesture..." }
            frameBuffer.clear()  // clear buffer so next gesture starts fresh
            consecutiveCount  = 0
            lastSpokenGesture = ""
            return
        }

        framesSinceLastRun++
        if (framesSinceLastRun >= RUN_EVERY_N_FRAMES) {
            framesSinceLastRun = 0
            val snapshot = ArrayList(frameBuffer)
            runModel(snapshot)
        }
    }

    /**
     * Returns true if the glove sensors show meaningful movement.
     * Checks the variance across the first 5 flex sensor values in the frame.
     * If all values are almost the same (low variance) = resting hand.
     * Tune MOTION_THRESHOLD based on your glove's sensor range.
     */
    private fun isGestureActive(frame: FloatArray): Boolean {
        if (frame.size < 5) return false

        // Use first 5 values (flex sensors)
        val flexValues = frame.slice(0..4)
        val mean = flexValues.average()
        val variance = flexValues.map { (it - mean) * (it - mean) }.average()

        Log.d("MOTION", "Variance: ${"%.2f".format(variance)}")

        // ✅ Tune this value — increase if too sensitive, decrease if not detecting
        val MOTION_THRESHOLD = 100.0
        return variance > MOTION_THRESHOLD
    }

    // ─────────────────────────────────────────────
    // 🔥 ML MODEL — runs on BT thread, UI updates via runOnUiThread
    // ─────────────────────────────────────────────

    private fun runModel(snapshot: List<FloatArray>) {
        try {
            // ✅ Log actual model input/output shape so we can verify it matches
            val inputShape  = tflite.getInputTensor(0).shape()   // e.g. [1, 100, 11]
            val outputShape = tflite.getOutputTensor(0).shape()  // e.g. [1, 30]
            Log.d("MODEL_SHAPE", "Input shape:  ${inputShape.toList()}")
            Log.d("MODEL_SHAPE", "Output shape: ${outputShape.toList()}")
            Log.d("MODEL_SHAPE", "Snapshot size: ${snapshot.size}, each frame size: ${snapshot[0].size}")

            // ✅ Build input using ACTUAL model shape (not hardcoded)
            val frames = inputShape[1]  // how many frames model expects
            val values = inputShape[2]  // how many values per frame

            if (snapshot.size < frames) {
                Log.w("MODEL", "Not enough frames: ${snapshot.size} < $frames")
                return
            }

            val input = Array(1) { Array(frames) { FloatArray(values) } }
            for (i in 0 until frames) {
                val frame = snapshot[i]
                for (j in 0 until minOf(values, frame.size)) {
                    input[0][i][j] = frame[j]
                }
            }

            val output = Array(1) { FloatArray(outputShape[1]) }
            tflite.run(input, output)

            val maxConf = output[0].max()
            val pred    = output[0].indices.maxByOrNull { output[0][it] } ?: 0

            // ✅ Guard against pred being out of labels range
            if (pred >= labels.size) {
                Log.e("MODEL", "Pred index $pred out of labels range ${labels.size}")
                runOnUiThread { tvGesture.text = "Label error ❌" }
                return
            }

            val result = labels[pred]
            Log.d("MODEL", "Predicted=$result confidence=${"%.2f".format(maxConf)}")

            // ✅ Step 1 — Reject low confidence
            if (maxConf < CONFIDENCE_THRESHOLD) {
                Log.w("MODEL", "Low confidence ${"%.2f".format(maxConf)} — skipping")
                runOnUiThread { tvGesture.text = "? (low confidence)" }
                consecutiveCount  = 0
                lastSpokenGesture = ""
                return
            }

            // ✅ Step 2 — Require same result N times in a row
            if (result == lastSpokenGesture) {
                consecutiveCount++
            } else {
                consecutiveCount  = 1
                lastSpokenGesture = result
            }

            Log.d("MODEL", "Consecutive '$result': $consecutiveCount/$CONSECUTIVE_NEEDED")

            if (consecutiveCount >= CONSECUTIVE_NEEDED) {
                consecutiveCount = 0  // reset after confirming

                // ✅ Step 3 — Confirmed gesture → update UI + speak
                runOnUiThread {
                    tvGesture.text = result
                    applyTTSSettings()
                    speakGesture(result)
                    saveGestureToHistory(result)
                }
            } else {
                // Gesture seen but not confirmed yet — show pending state
                runOnUiThread { tvGesture.text = "$result..." }
            }

        } catch (e: Exception) {
            // ✅ Catch any model crash so app never closes
            Log.e("MODEL", "Model error: ${e.message}", e)
            runOnUiThread { tvGesture.text = "Model error ❌" }
        }
    }

    // ─────────────────────────────────────────────
    // 🎨 UI / TTS / LIFECYCLE
    // ─────────────────────────────────────────────

    override fun onResume() {
        super.onResume()
        applyUISizeAndTheme()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.top_app_bar_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_settings -> {
                startActivity(Intent(this, SettingsActivity::class.java))
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun showDummyGesture() {
        // ✅ Only show dummy text if not connected — avoids overwriting real data
        if (bluetoothSocket == null || bluetoothSocket?.isConnected == false) {
            tvGesture.text = dummyGestures.random()
        }
        applyUISizeAndTheme()
    }

    private fun speakGesture(text: String) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, null)
    }

    private fun saveGestureToHistory(gesture: String) {
        val prefs = PreferenceManager.getDefaultSharedPreferences(this)
        if (prefs.getBoolean("save_history", true)) {
            lifecycleScope.launch {
                gestureDao.insertGesture(GestureEntity(gesture = gesture))
            }
        }
    }

    private fun applyTTSSettings() {
        val prefs  = PreferenceManager.getDefaultSharedPreferences(this)
        val locale = if (prefs.getString("tts_language", "English") == "urdu") Locale("ur") else Locale.US
        tts.language = locale
        tts.setSpeechRate(prefs.getInt("tts_rate", 5) / 5f)
        tts.setPitch(prefs.getInt("tts_pitch", 5) / 5f)
    }

    private fun applyUISizeAndTheme() {
        val prefs  = PreferenceManager.getDefaultSharedPreferences(this)
        tvGesture.setTextSize(TypedValue.COMPLEX_UNIT_SP, prefs.getInt("text_size", 18).toFloat())

        val isDark = prefs.getString("theme", "Light") == "Dark"
        val bg     = if (isDark) android.R.color.black else android.R.color.white
        val text   = if (isDark) android.R.color.white else android.R.color.black

        findViewById<View>(R.id.coordinatorLayout)
            .setBackgroundColor(ContextCompat.getColor(this, bg))
        tvGesture.setTextColor(ContextCompat.getColor(this, text))
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) applyTTSSettings()
    }

    override fun onDestroy() {
        super.onDestroy()
        tts.shutdown()
        closeSocket()
    }

    companion object {
        private const val REQUEST_BT = 1
    }
}