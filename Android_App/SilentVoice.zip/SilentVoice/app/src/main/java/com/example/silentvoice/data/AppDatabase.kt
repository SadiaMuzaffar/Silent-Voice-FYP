package com.example.silentvoice.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [GestureEntity::class], version = 1)
abstract class AppDatabase : RoomDatabase() {

    abstract fun gestureDao(): GestureDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "silentvoice_db"
                )
                    .fallbackToDestructiveMigration()
                    // explicitly clear all tables if migration needed
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
