package com.example.silentvoice.com.example.silentvoice.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "gesture_history")
data class Gesture(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val text: String,
    val timestamp: Long
)